<?php

$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = 	"EXEC getSale
			@val = ".$_POST['val']."";
$result = sqlsrv_query($connect, $query);
$output = "";
while ($row = sqlsrv_fetch_array($result))
	{
		$output .= '
		<tr>
			<td>'.$row["id"].'</td>
			<td>'.$row["_name"].'</td>
			<td>'.$row["sale"].'</td>
		</tr>
		';
	}

echo $output;

?>