<!DOCTYPE html>
<html>
	<head>
		<title>Employee Management</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link href="styles.css" rel="stylesheet" type="text/css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
		<header>
			<div class="new">
			<nav>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="order_static.php">Orders Statics</a></li>
					<li><a href="sale_static.php">Sale Statics</a></li>
					<li><a href="func.php">Functions</a></li>
					<li><input onkeydown="keyCode(event)" type="text" placeholder="Search.." id="search_txt"></li>
					<li><button type="button" name="search_button" id="search_button" class="btn btn-success btn-xs">Go</button></li>
				</ul>
			</nav>
			</div>
		</header>

		<div class="container">
			<br />
			
			<h3 align="center">Employee Management</h3>
			<br />
			<div align="right" style="margin-bottom:5px;">
				<button type="button" name="add_button" id="add_button" class="btn btn-success btn-xs">Add</button>
			</div>

			<div class="table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Address</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Birthday</th>
							<th>Salary</th>
							<th>MgrID</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</body>
</html>

<div id="apicrudModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="post" id="api_crud_form">
				<div class="modal-header">
		        	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        	<h4 class="modal-title">Add Data</h4>
		      	</div>
		      	<div class="modal-body">
		      		<div class="form-group">
			        	<label>Enter ID</label>
			        	<input type="text" name="employ_id" id="employ_id" class="form-control" />
					</div>
					<fbody></fbody>
			        <div class="form-group">
			        	<label>Enter Name</label>
			        	<input type="text" name="employ_name" id="employ_name" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter Address</label>
			        	<input type="text" name="employ_add" id="employ_add" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter Email</label>
			        	<input type="text" name="email" id="email" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter Phone</label>
			        	<input type="tel" name="phone" id="phone" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter Birthdate</label>
			        	<input type="date" name="bdate" id="bdate" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter Salary</label>
			        	<input type="number" step = "0.01" name="salary" id="salary" class="form-control" />
					</div>
					<div class="form-group">
			        	<label>Enter MgrID</label>
			        	<input type="number" name="mgrid" id="mgrid" class="form-control" />
			        </div>
			    </div>
			    <div class="modal-footer">
			    	<input type="hidden" name="hidden_id" id="hidden_id" />
			    	<input type="hidden" name="action" id="action" value="insert" />
			    	<input type="submit" name="button_action" id="button_action" class="btn btn-info" value="Insert" />
			    	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	      		</div>
			</form>
		</div>
  	</div>
</div>


<script type="text/javascript">
function keyCode(event) {
	if (event.keyCode == 13) 
	{
	var key = $('#search_txt').val();
		$.ajax({
			url:"search_fetch.php",
			method:"POST",
			data:{key:key},
			success:function(data)
			{
				$('tbody').html(data);
			}
		});
	}
}

$(document).ready(function(){

	fetch_data();

	function fetch_data()
	{
		$.ajax({
			url:"fetch.php",
			success:function(data)
			{
				$('tbody').html(data);
			}
		})
	}

	$('#add_button').click(function(){
		$('#api_crud_form')[0].reset();
		$('#action').val('insert');
		$('#button_action').val('Insert');
		$('.modal-title').text('Add Data');
		$('#apicrudModal').modal('show');
		$('fbody').html('<div class="form-group"><label>Enter Username</label><input type="text" name="user" id="user" class="form-control" /></div><div class="form-group"><label>Enter Password</label><input type="password" name="pass" id="pass" class="form-control" /></div>');
	});

	$('#api_crud_form').on('submit', function(event) {
		event.preventDefault();
		var flag = true;
		if ($('#employ_id').val() == '')
		{
			alert("Enter ID");
			flag = false;
			return false;  
		}
		if ($('#user').val() == '')
		{
			alert("Enter Username");
			flag = false;
			return false;  
		}

		if ($('#pass').val() == '')
		{
			alert("Enter Password");
			flag = false;
			return false;  
		}

		if ($('#employ_name').val() == '')
		{
			alert("Enter Name");
			flag = false;
            return false; 
		}

		if ($('#employ_add').val() == '')
		{
			alert("Enter Address");
			flag = false;
            return false; 
		}

		if ($('#email').val() == '')
		{
			alert("Enter Email");
			flag = false;
            return false; 
		}

		if ($('#phone').val() == '')
		{
			alert("Enter Phone");
			flag = false;
            return false; 
		}

		if ($('#bdate').val() == '')
		{
			alert("Enter Birthday");
			flag = false;
            return false; 
		}

		if ($('#salary').val() == '')
		{
			alert("Enter Salary");
			flag = false;
            return false; 
		}

		var form_data = $(this).serialize();
		$.ajax({
			url:"insert.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{
				alert(data);
				fetch_data();
				if (data == 'insert')
				{	
					$('#api_crud_form')[0].reset();
					$('#apicrudModal').modal('hide');
					alert("Data Inserted using PHP API");
				}
				if (data == 'update')
				{
					$('#api_crud_form')[0].reset();
					$('#apicrudModal').modal('hide');
					alert("Data Updated using PHP API");
				}
			}
		});
		
	});

	$(document).on('click', '.edit', function(){
		var id = $(this).attr('id');
		$('fbody').html('');
		arr = new Array();
		$.ajax({
			url:"fetch_single.php",
			method:"POST",
			data:{id:id},
			dataType:"json",
			success:function(data)
			{
				arr = data;
				$('#apicrudModal').modal('show');
				$('#employ_id').val(id);
				$('#employ_name').val(arr['name']);
				$('#employ_add').val(arr['add']);
				$('#email').val(arr['email']);
				$('#phone').val(arr['phone']);
				$('#bdate').val(arr['bdate']);
				$('#salary').val(arr['salary']);
				$('#mgrid').val(arr['mgr']);
				$('#action').val('update');
				$('#button_action').val('Update');
				$('.modal-title').text('Edit Data');
				$('#apicrudModal').modal('show');
			}
		})
	});

	$('#search_button').click(function(){
		var key = $('#search_txt').val();
		$.ajax({
			url:"search_fetch.php",
			method:"POST",
			data:{key:key},
			success:function(data)
			{
				$('tbody').html(data);
			}
		});
	});

	$(document).on('click', '.delete', function(){
		var id = $(this).attr('id');
		alert(id);
		var action = 'delete';
		if (confirm("Are you sure you want to remove this data using PHP API?"))
		{
			$.ajax({
				url:"delete.php",
				method:"POST",
				data:{id:id},
				success:function(data)
				{
					fetch_data();
					alert("Data Deleted using PHP API");
				}
			});
		}
	});

});
</script>