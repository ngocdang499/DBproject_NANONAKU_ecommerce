<!DOCTYPE html>
<html>
	<head>
		<title>Functions</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link href="styles.css" rel="stylesheet" type="text/css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
		<header>
			<div class="new">
			<nav>
				<ul>
					<li><a href="order_static.php">Orders Statics</a></li>
					<li><a href="sale_static.php">Sale Statics</a></li>
					<li><a href="func.php">Functions</a></li>
				</ul>
			</nav>
			</div>
		</header>

		<div class="container">
			<br />
			<div align="left">
				<button onclick="location.href='index.php';" type="button" name="return_button" id="add_button" class="btnreturn">Return</button>
			</div>
			<h3 align="center">Some Functions</h3>
			<br />
            
			<div class="row">
                <div class="column">
                    <h5 align="center">Calculate Sale of Day</h5>
                    <div class="form-group">
			        	<label>Enter Date</label>
			        	<input type="date" name="date" id="date" class="form-control" />
                    </div>
                    <div align="right" style="margin-bottom:5px;">
				        <button type="button" name="sgo_button" id="sgo_button" class="btn btn-success btn-xs">Go</button>
			        </div>
                </div>

                <div class="column">
                    <h5 align="center">Find MVE</h5>
                    <div class="form-group">
			        	<label>Enter Manager ID</label>
			        	<input type="text" name="id" id="id" class="form-control" />
                    </div>
                    <div align="right" style="margin-bottom:5px;">
				        <button type="button" name="mvego_button" id="mvego_button" class="btn btn-success btn-xs">Go</button>
                    </div>
                    <div class="table-responsive">
				    <table class="table table-bordered table-striped">
					    <thead></thead>
					    <tbody></tbody>
				</table>
			</div>
                </div>
            </div>
		</div>
	</body>
</html>

<script type="text/javascript">
$('#sgo_button').click(function() {
	date = $('#date').val();

    if (date == '') {
        alert('Enter Day');
        return false;
    }
	$.ajax({
			url:"datesale.php",
			method:"POST",
			data:{date:date},
			success:function(data){
                alert(data)
            }
    });
});

$('#mvego_button').click(function() {
	id = $('#id').val();

    if (id == '') {
        alert('Enter ID');
        return false;
    }
	$.ajax({
			url:"mve.php",
			method:"POST",
			data:{id:id},
			success:function(data){
                $('thead').html("<tr><th>ID</th><th>Name</th><th>NumberOfProduct</th></tr>");
                $('tbody').html(data);
            }
    });
});
</script>