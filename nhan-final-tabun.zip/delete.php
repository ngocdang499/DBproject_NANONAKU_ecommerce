<?php
$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = "DELETE FROM dbo.employee WHERE id = '".$_POST['id']."'
        DELETE FROM dbo.account WHERE id = '".$_POST['id']."'";
$result = sqlsrv_query($connect, $query);
if ($result === false) {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error[ 'SQLSTATE']."\nCode: ".$error[ 'code']."\nMessage: ".$error[ 'message']."";
        }
    }
}
echo 'deleted';
?>