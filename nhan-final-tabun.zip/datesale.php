<?php
$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = "SELECT dbo.incomeOfDay('".$_POST['date']."')";
$result = sqlsrv_query($connect, $query);
if ($result === false) {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error[ 'SQLSTATE']."\nCode: ".$error[ 'code']."\nMessage: ".$error[ 'message']."";
        }
    }
}
if (sqlsrv_fetch($result) === false) {
    die(print_r(sqlsrv_errors(), true));
}
echo sqlsrv_get_field($result, 0);
?>