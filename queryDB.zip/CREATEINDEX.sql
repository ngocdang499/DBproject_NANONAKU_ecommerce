USE Nanonaku

---- Tao index cho nhung cho tim kiem tren do nhieu nhat, khong tao qua nhieu cho nhung cai khong can thiet --

CREATE INDEX idx_employ_id
ON employee(id)

CREATE INDEX idx_order_id
ON _order(id)