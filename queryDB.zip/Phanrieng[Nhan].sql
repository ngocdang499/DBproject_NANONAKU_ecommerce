CREATE PROCEDURE dbo.InsertEmployee
@id			VARCHAR(10),
@username	VARCHAR(30),
@pass		VARCHAR(50),
@name		VARCHAR(30),
@address	VARCHAR(100),
@email		VARCHAR(50),
@phone		VARCHAR(10),
@bdate		DATE,
@salary		DECIMAL(10,2) = 120,
@mgrid		VARCHAR(10)
AS
BEGIN
	IF EXISTS(SELECT 1 FROM employee WHERE id = @id)
		RAISERROR ('ID da ton tai', 10, 1)
	ELSE IF (@mgrid IS NOT NULL) AND (NOT EXISTS(SELECT 1 FROM employee WHERE id = @mgrid))
		RAISERROR ('Khong tim thay nguoi quan ly', 10, 1)
	ELSE IF @email NOT LIKE '%@%'
		RAISERROR ('Email khong hop le', 10, 1)
	ELSE IF @bdate > CAST(GETDATE() AS DATE)
		RAISERROR ('Ngay sinh khong hop le', 10, 1)
	ELSE IF DATEDIFF(DAY, @bdate, GETDATE()) / 365 < 18
		RAISERROR ('Nhan vien chua du 18 tuoi', 10, 1)
	ELSE
		BEGIN
			INSERT INTO dbo.account(id, name, password)
			VALUES (@id, @username, @pass)
			INSERT INTO dbo.employee(id, _name, _address, email, phone, bdate, salary, mgrid) 
			VALUES(@id, @name, @address, @email, @phone, @bdate, @salary, @mgrid)
		END
END

CREATE TRIGGER update_datetime
ON _order
FOR UPDATE
AS
BEGIN
	SET NOCOUNT ON
	UPDATE	_order 
	SET		check_date = GETDATE()
	FROM	_order o	INNER JOIN	INSERTED i	ON o.id = i.id	AND i.del_status = 'N'
END

CREATE TRIGGER increase_salary
ON _order
FOR UPDATE
AS
BEGIN
	DECLARE	@emp	VARCHAR(10)
	DECLARE	@id		VARCHAR(10)
	DECLARE	@before	DECIMAL(15,2)
	DECLARE	@after	DECIMAL(15,2)
	DECLARE @hs		INT
	SELECT	@emp = o.id_employ, @id = o.id 
	FROM	_order o	INNER JOIN	INSERTED i	ON	o.id = i.id	AND i.del_status = 'Y'
	IF @emp IS NOT NULL
		BEGIN
			SELECT	@before = ISNULL(SUM(total), 0)
			FROM	(SELECT	o.id_employ, o.id, op.amount * op.price as total
					FROM	_order o INNER JOIN order_product op ON o.id = op.id_order AND o.id != @id AND o.del_status = 'Y') temp
			WHERE	temp.id_employ = @emp
			SELECT  @after = ISNULL(SUM(total), 0)
			FROM	(SELECT	o.id_employ, o.id, op.amount * op.price as total
					FROM	_order o INNER JOIN order_product op ON o.id = op.id_order AND o.del_status = 'Y') temp
			WHERE	temp.id_employ = @emp
			IF (CEILING(@before/100.0) = FLOOR(@before/100.0))
				SET @hs = FLOOR(@after/100.0) - CEILING(@before/100.0)
			ELSE 
				SET @hs = FLOOR(@after/100.0) - CEILING(@before/100.0) + 1
			IF @hs > 0
				BEGIN
					UPDATE	employee
					SET		salary = salary * POWER(1.05, @hs)
					WHERE	id = @emp
				END
		END
END

CREATE PROCEDURE dbo.getStatics
AS
BEGIN
	SELECT		e.id, e._name, COUNT(o.id) as number
	FROM		employee e LEFT JOIN _order o ON e.id = o.id_employ
	WHERE		order_date IS NULL OR DATEDIFF(DAY, order_date, GETDATE()) <= 30
	GROUP BY	e.id, e._name
	ORDER BY	number		DESC
END

CREATE PROCEDURE dbo.getSale
@val	DECIMAL(15,2)
AS
BEGIN
	SELECT		e.id, e._name, ISNULL(SUM(total), 0) as sale
	FROM		employee e LEFT JOIN	(SELECT	o.id_employ, o.id, op.amount * op.price as total
										FROM	_order o, order_product op
										WHERE	o.id = op.id_order) temp
							ON		e.id = temp.id_employ
	GROUP BY	e.id, e._name
	HAVING		ISNULL(SUM(total), 0) < @val
	ORDER BY	sale		DESC
END

CREATE FUNCTION	dbo.incomeOfDay(@date DATE)
RETURNS	DECIMAL(20,2)
AS
BEGIN
	DECLARE	@income	DECIMAL(20,2)
	SET	@income = 0
	IF	@date > CAST(GETDATE() AS DATE)
			RETURN CAST('Ngay nay chua den' as INT)
	ELSE
		BEGIN
			SELECT	@income = ISNULL(SUM(total), 0)
			FROM	(SELECT	op.amount * op.price as total
					FROM	_order o INNER JOIN order_product op ON o.id = op.id_order AND o.del_status = 'Y' AND CAST(o.delivery_date AS DATE) = @date) temp
		END
	RETURN	@income
END

SELECT dbo.incomeOfDay('08-12-2019')

CREATE FUNCTION	dbo.mveOfManager(@mgr VARCHAR(10))
RETURNS	@ret TABLE 
		(id						VARCHAR(10)		PRIMARY KEY		DEFAULT '',
		employ_name				VARCHAR(30),
		numberOfProduct			INT)
AS
BEGIN
	IF EXISTS(SELECT 1 FROM employee WHERE mgrid = @mgr)
		BEGIN
			INSERT	@ret
			SELECT	e.id, e._name, ISNULL(SUM(amount), 0) as numOfProduct
			FROM	employee e LEFT JOIN	(SELECT	o.id_employ, o.id, op.amount
											FROM	_order o INNER JOIN order_product op ON o.id = op.id_order) temp
					ON		e.id = temp.id_employ 
			WHERE	e.mgrid = @mgr
			GROUP BY	e.id, e._name
			HAVING	ISNULL(SUM(amount), 0)	=
					(SELECT MAX(total)
					FROM	(SELECT	e.id, ISNULL(SUM(amount), 0) as total
							FROM	employee e	LEFT JOIN	(SELECT	o.id_employ, o.id, op.amount
															FROM	_order o INNER JOIN order_product op ON o.id = op.id_order) temp
												ON		e.id = temp.id_employ 
							WHERE	e.mgrid = @mgr
							GROUP BY	e.id) t
					)
		END
	RETURN
END