-----constraint------
ALTER TABLE write
ADD CONSTRAINT fk_idauthor_author FOREIGN KEY (id_author)
			   REFERENCES author(id),
	CONSTRAINT fk_id_book_write_book FOREIGN KEY (id_book)
				REFERENCES book(id)

-----constraint------
ALTER TABLE book
ADD CONSTRAINT fk_id_product FOREIGN KEY (id)
				REFERENCES product(id)

-----constraint------
ALTER TABLE publish	
ADD CONSTRAINT fk_id_publisher_publisher FOREIGN KEY (id_publisher)
				REFERENCES publisher(id),
	CONSTRAINT fk_id_book_publish_book FOREIGN KEY (id_book)
				REFERENCES book(id)

-----constraint------
ALTER TABLE image_prod
ADD CONSTRAINT fk_id_image_product_product FOREIGN KEY (id_product)
				REFERENCES product(id)

-----constraint------
ALTER TABLE otherProduct
ADD CONSTRAINT fk_id_other_product_product FOREIGN KEY (id_product)
				REFERENCES Product(id),
	CONSTRAINT fk_id_type_typeProduct FOREIGN KEY (id_type)
				REFERENCES typeProduct(id),
	CONSTRAINT fk_id_producer_producer FOREIGN KEY (id_producer)
				REFERENCES producer(id)

-----constraint------
ALTER TABLE supply
ADD CONSTRAINT fk_id_product_supply_product FOREIGN KEY (id_product)
				REFERENCES product(id),
	CONSTRAINT fk_id_warehouse_warehouse FOREIGN KEY (id_warehouse)
				REFERENCES warehouse(id),
	CONSTRAINT fk_id_supplier_supplier FOREIGN KEY (id_supplier)
				REFERENCES supplier(id)

-----constraint------
ALTER TABLE order_product
ADD CONSTRAINT fk_id_product_order_product_product FOREIGN KEY (id_product)
				REFERENCES product(id),
	CONSTRAINT fk_id_order_order_product_product FOREIGN KEY (id_order)
				REFERENCES _order(id)

-----constraint------
ALTER TABLE _order
ADD CONSTRAINT fk_id_trans_company_trans_company FOREIGN KEY (id_trans_company)
				REFERENCES trans_company(id),
	CONSTRAINT fk_id_employ_order_employee FOREIGN KEY (id_employ)
				REFERENCES employee(id),
	CONSTRAINT fk_id_cart_order_cart FOREIGN KEY (id_cart, stt)
				REFERENCES cart(u_id, stt)
--	CONSTRAINT fk_stt_order_cart FOREIGN KEY (stt)
--				REFERENCES cart(stt)

-----constraint------
ALTER TABLE _apply
ADD CONSTRAINT fk_id_service_service FOREIGN KEY (id_service)
				REFERENCES _service(id),
	CONSTRAINT fk_id_order_order FOREIGN KEY (id_order)
				REFERENCES _order(id)

-----constraint------
ALTER TABLE refund
ADD CONSTRAINT fk_id_service_refund_service FOREIGN KEY (id_service)
				REFERENCES _service(id)

-----constraint------
ALTER TABLE fast_deliver 
ADD CONSTRAINT fk_id_service_fast_deliver_service FOREIGN KEY (id_service)
				REFERENCES _service(id)

-----constraint------
ALTER TABLE book_care
ADD CONSTRAINT fk_id_service_book_care_service FOREIGN KEY (id_service)
				REFERENCES _service(id)

-----constraint------
ALTER TABLE employee
ADD CONSTRAINT fk_mgrid_employee_employee FOREIGN KEY (mgrid)
				REFERENCES employee(id),
	CONSTRAINT fk_id_employee_account FOREIGN KEY (id)
				REFERENCES account(id)

-----constraint------
ALTER TABLE cart
ADD CONSTRAINT fk_u_id_cart_customer FOREIGN KEY (u_id)
				REFERENCES customer(id)

-----constraint------
ALTER TABLE cart_product
ADD CONSTRAINT fk_id_product_product FOREIGN KEY (id_product)
				REFERENCES product(id),
	CONSTRAINT fk_u_id_cart_product_cart FOREIGN KEY (u_id, stt)
				REFERENCES cart(u_id, stt)
	--CONSTRAINT fk_stt_cart_product_cart FOREIGN KEY (stt)
		--		REFERENCES cart(stt)

-----constraint------
ALTER TABLE member
ADD CONSTRAINT fk_u_id_member_customer FOREIGN KEY (u_id)
				REFERENCES customer(id)

-----constraint------
ALTER TABLE vip
ADD CONSTRAINT fk_u_id_vip_customer FOREIGN KEY (u_id)
				REFERENCES customer(id)

-----constraint------
ALTER TABLE customer
ADD CONSTRAINT fk_id_customer_account FOREIGN KEY(id)
				REFERENCES account(id)

-----constraint------
ALTER TABLE address_user
ADD CONSTRAINT fk_id_customer_customer FOREIGN KEY (id_customer)
				REFERENCES customer(id)

-----constraint------
ALTER TABLE book_type
ADD CONSTRAINT fk_id_book_book FOREIGN KEY (id_book)
				REFERENCES book(id)
