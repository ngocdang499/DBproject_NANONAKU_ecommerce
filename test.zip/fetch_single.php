<?php
$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = "SELECT * FROM dbo.employee WHERE id = ".$_POST['id']."";
$result = sqlsrv_query($connect, $query);
$row = sqlsrv_fetch_array($result);
$data['name'] = $row["_name"];
$data['add'] = $row["_address"];
$data['email'] = $row["email"];
$data['phone'] = $row["phone"];
$data['bdate'] = $row["bdate"]->format('Y-m-d');
$data['salary'] = $row["salary"];
$data['mgr'] = $row["mgrid"];
if ($result === false) {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
            echo "code: ".$error[ 'code']."<br />";
            echo "message: ".$error[ 'message']."<br />";
        }
    }
}
echo json_encode($data);
?>