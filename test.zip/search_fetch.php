<?php

//fetch.php

$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = "SELECT * FROM employee WHERE id LIKE '%".$_POST['key']."%' OR _name LIKE '%".$_POST['key']."%'";
$result = sqlsrv_query($connect, $query);
$output = "";
while ($row = sqlsrv_fetch_array($result))
	{
		$output .= '
		<tr>
			<td>'.$row["id"].'</td>
			<td>'.$row["_name"].'</td>
			<td>'.$row["_address"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$row["phone"].'</td>
			<td>'.$row["bdate"]->format('d M y').'</td>
			<td>'.$row["salary"].'</td>
			<td>'.$row["mgrid"].'</td>
			<td><button type="button" name="edit" class="btn btn-warning btn-xs edit" id="'.$row["id"].'">Edit</button></td>
			<td><button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row["id"].'">Delete</button></td>
		</tr>
		';
	}

echo $output;

?>