<!DOCTYPE html>
<html>
	<head>
		<title>Sale Statics</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link href="styles.css" rel="stylesheet" type="text/css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
		<header>
			<div class="new">
			<nav>
				<ul>
					<li><a href="order_static.php">Orders Statics</a></li>
					<li><a href="sale_static.php">Sale Statics</a></li>
					<li><a href="func.php">Functions</a></li>
				</ul>
			</nav>
			</div>
		</header>

		<div class="container">
			<br />
			<div align="left">
				<button onclick="location.href='index.php';" type="button" name="return_button" id="add_button" class="btnreturn">Return</button>
			</div>
			<h3 align="center">Total Sale by an Employee</h3>
			<br />
            
			<div class="table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Sale</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</body>
</html>

<script type="text/javascript">
$(document).ready(function() {
	get();

	function get()
	{
		$.ajax({
			url:"salestat.php",
			success:function(data)
			{
				$('tbody').html(data);
			}
		})
	}
});
</script>