<?php
$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$query = "SELECT * FROM dbo.mveOfManager('".$_POST['id']."')";
$result = sqlsrv_query($connect, $query);
$output = '';
if ($result === false) {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error[ 'SQLSTATE']."\nCode: ".$error[ 'code']."\nMessage: ".$error[ 'message']."";
        }
    }
}
while ($row = sqlsrv_fetch_array($result))
	{
		$output .= '
		<tr>
			<td>'.$row["id"].'</td>
			<td>'.$row["employ_name"].'</td>
			<td>'.$row["numberOfProduct"].'</td>
		</tr>
		';
    }
echo $output;
?>