<?php
$serverName = "DESKTOP-CFLRNBI";
$connectionInfo = array("Database"=>"Nanonaku");
$connect = sqlsrv_connect($serverName, $connectionInfo);
$salary = ($_POST['salary'] == "") ? '120' : $_POST['salary'];
$mgr = ($_POST['mgrid'] == "") ? 'NULL' : $_POST['mgrid'];
if ($_POST['action'] == 'insert') {
    $query = "EXECUTE InsertEmployee
    @id		= ".$_POST['employ_id'].",
    @username=".$_POST['user'].",
    @pass   =".$_POST['pass'].",
    @name	= '".$_POST['employ_name']."',
    @address= '".$_POST['employ_add']."',
    @email	= '".$_POST['email']."',
    @phone	= '".$_POST['phone']."',
    @bdate	= '".$_POST['bdate']."',
    @salary = ".$salary.",
    @mgrid	= ".$mgr."";
    $msg = 'insert';
}
else if ($_POST['action'] == 'update') {
    $query = "UPDATE    employee
    SET _name	= '".$_POST['employ_name']."',
        _address= '".$_POST['employ_add']."',
        email	= '".$_POST['email']."',
        phone	= '".$_POST['phone']."',
        bdate	= '".$_POST['bdate']."',
        salary = '".$salary."',
        mgrid	= ".$mgr."
    WHERE id	= ".$_POST['employ_id']."";
    $msg = 'update';
}
$result = sqlsrv_query($connect, $query);
if ($result === false) {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error[ 'SQLSTATE']."\nCode: ".$error[ 'code']."\nMessage: ".$error[ 'message']."";
        }
    }
    $msg = 'fail';
}
else echo $msg;
?>